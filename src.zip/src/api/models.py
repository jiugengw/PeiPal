"""Request models for the website API."""

from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, EmailStr, Field


class FamilyCreate(BaseModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{"name": "Lim Family"}]})

    name: str = Field(min_length=1, max_length=120)


class FamilyUpdate(BaseModel):
    name: str = Field(min_length=1, max_length=120)


class OlderAdultCreate(BaseModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "family_id": 1,
        "name": "Mary Lim",
        "preferred_name": "Mary",
        "age": 75,
        "language": "English",
        "email": "mary@example.com",
        "mobility_notes": "Prefers seated activities",
        "transport_notes": "Family can help arrange transport",
    }]})

    family_id: int
    name: str = Field(min_length=1, max_length=120)
    preferred_name: str | None = Field(default=None, max_length=120)
    age: int | None = Field(default=None, ge=0, le=130)
    language: str | None = Field(default=None, max_length=80)
    email: EmailStr | None = Field(
        default=None,
        description="Optional. When present, the older adult also receives the plan decision.",
    )
    mobility_notes: str | None = Field(default=None, max_length=2_000)
    transport_notes: str | None = Field(default=None, max_length=2_000)


class OlderAdultUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    preferred_name: str | None = Field(default=None, max_length=120)
    age: int | None = Field(default=None, ge=0, le=130)
    language: str | None = Field(default=None, max_length=80)
    email: EmailStr | None = None
    mobility_notes: str | None = Field(default=None, max_length=2_000)
    transport_notes: str | None = Field(default=None, max_length=2_000)


class FamilyMemberRelationship(BaseModel):
    """How one family member is related to one older adult."""

    model_config = ConfigDict(json_schema_extra={"examples": [{
        "older_adult_id": 1,
        "relationship": "Daughter",
    }]})

    older_adult_id: int
    relationship: str = Field(min_length=1, max_length=80)


class FamilyMemberCreate(BaseModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "family_id": 1,
        "name": "Anna Lim",
        "email": "anna@example.com",
        "relationships": [{"older_adult_id": 1, "relationship": "Daughter"}],
    }]})

    family_id: int
    name: str = Field(min_length=1, max_length=120)
    email: EmailStr | None = None
    relationships: list[FamilyMemberRelationship] = Field(min_length=1, max_length=20)


class FamilyMemberUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=120)
    email: EmailStr | None = None
    relationships: list[FamilyMemberRelationship] | None = Field(
        default=None, min_length=1, max_length=20
    )


class PlanCreate(BaseModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "family_id": 1,
        "older_adult_id": 1,
        "activity_id": 1,
    }]})

    family_id: int
    older_adult_id: int
    activity_id: int


class PlanUpdate(BaseModel):
    """Only cancellation is a direct status change.

    Asking the family, approving, rejecting, and completing all happen through
    the coordination endpoints, so no single account can shortcut them.
    """

    model_config = ConfigDict(json_schema_extra={"examples": [{"status": "cancelled"}]})

    status: Literal["cancelled"]


class PlanDecisionRequest(BaseModel):
    decision: Literal["approved", "rejected"]
    reason: str | None = Field(default=None, max_length=2_000)


class DecisionDeliveryResponse(BaseModel):
    recipient_role: Literal["family_member", "older_adult"]
    name: str
    status: Literal["sent", "already_sent", "failed"]
    provider_id: str | None = None
    error: str | None = None


class PlanDecisionResponse(BaseModel):
    plan_id: int
    status: Literal["approved", "rejected"]
    decided_by: str
    decided_at: datetime
    message: str
    deliveries: list[DecisionDeliveryResponse] = []


class DecisionDeliveryListResponse(BaseModel):
    deliveries: list[DecisionDeliveryResponse]


class PlanDecisionNotificationResponse(BaseModel):
    id: int
    plan_id: int
    recipient_role: Literal["family_member", "older_adult"]
    family_member_id: int | None = None
    older_adult_id: int | None = None
    recipient_name: str
    recipient_email: str | None = None
    status: Literal["pending", "sent", "failed"]
    provider_id: str | None = None
    error_message: str | None = None
    attempted_at: datetime | None = None
    sent_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class PlanDecisionNotificationListResponse(BaseModel):
    notifications: list[PlanDecisionNotificationResponse]


class SupportOfferCreate(BaseModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "support_type": "transport",
        "note": "I can drive Mary there.",
    }]})

    support_type: Literal[
        "join",
        "remind",
        "transport",
        "alternative",
        "booking",
        "encourage",
    ]
    note: str | None = Field(default=None, max_length=2_000)


class PlanNotificationCreate(BaseModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{
        "family_member_ids": [1, 2],
    }]})

    family_member_ids: list[int] = Field(min_length=1, max_length=20)


class CoordinationTaskResponse(BaseModel):
    task_type: Literal["approval", "registration", "transport"]
    status: Literal["open", "claimed", "done", "not_needed", "approved", "rejected"]
    owner_name: str | None = None
    decided_by_name: str | None = None
    reason: str | None = None
    version: int


class CoordinationEventResponse(BaseModel):
    task_type: Literal["approval", "registration", "transport"] | None = None
    action: str
    actor_name: str
    detail: str | None = None
    created_at: datetime


class CoordinationActivityResponse(BaseModel):
    name: str
    location: str
    start_at: datetime
    info_link: str


class CoordinationStateResponse(BaseModel):
    """The shared view of a plan. Never carries private contact details."""

    plan_id: int
    plan_status: Literal["draft", "coordinating", "ready", "completed", "rejected", "cancelled"]
    older_adult: str
    activity: CoordinationActivityResponse
    tasks: list[CoordinationTaskResponse]
    events: list[CoordinationEventResponse]
    responding_as: str | None = None


class CoordinationActionRequest(BaseModel):
    action: Literal["approve", "reject", "claim", "take_over", "release", "complete", "not_needed"]
    expected_version: int
    reason: str | None = Field(default=None, max_length=2_000)


class CoordinationLaunchResponse(BaseModel):
    plan_id: int
    plan_status: str
    deliveries: list["DecisionDeliveryResponse"]
    message: str


class SignInCodeRequest(BaseModel):
    model_config = ConfigDict(json_schema_extra={"examples": [{"email": "mary@example.com"}]})

    email: EmailStr


class SignInCodeResponse(BaseModel):
    sent: bool
    message: str


class ViewerResponse(BaseModel):
    """Which kind of person is signed in, and what they may act on."""

    role: Literal["organizer", "older_adult", "unknown"]
    family_id: int | None = None
    older_adult_id: int | None = None
    display_name: str | None = None


class VoiceSessionResponse(BaseModel):
    client_secret: str
    expires_at: int | None = None
    session: dict[str, Any] | None = None


class FamilyResponse(FamilyCreate):
    id: int
    created_by: str
    created_at: datetime


class OlderAdultResponse(OlderAdultCreate):
    id: int
    created_by: str
    created_at: datetime


class FamilyMemberResponse(BaseModel):
    id: int
    family_id: int
    name: str
    email: EmailStr | None = None
    relationships: list[FamilyMemberRelationship]
    created_at: datetime
    is_account_owner: bool = False


class ActivityResponse(BaseModel):
    id: int
    dedupe_key: str
    name: str
    description: str | None = None
    location: str
    start_at: datetime
    end_at: datetime | None = None
    cost: float | None = None
    currency: str
    info_link: str
    signup_link: str | None = None
    tags: list[str] | None = None
    status: str
    first_seen_at: datetime
    last_seen_at: datetime
    last_checked_at: datetime
    created_at: datetime
    updated_at: datetime


class ActivityListResponse(BaseModel):
    activities: list[ActivityResponse]


class ActivityRecommendationResponse(BaseModel):
    activity: ActivityResponse
    recommendation_score: float
    match_factors: dict[str, float]


class ActivityRecommendationListResponse(BaseModel):
    recommendations: list[ActivityRecommendationResponse]


class FamilyListResponse(BaseModel):
    families: list[FamilyResponse]


class OlderAdultListResponse(BaseModel):
    older_adults: list[OlderAdultResponse]


class FamilyMemberListResponse(BaseModel):
    family_members: list[FamilyMemberResponse]


class PlanResponse(BaseModel):
    id: int
    family_id: int
    older_adult_id: int
    activity_id: int
    status: Literal["draft", "coordinating", "ready", "completed", "rejected", "cancelled"]
    created_by: str
    approved_by: str | None = None
    approved_at: datetime | None = None
    shared_at: datetime | None = None
    cancelled_at: datetime | None = None
    ready_at: datetime | None = None
    completed_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class PlanListResponse(BaseModel):
    plans: list[PlanResponse]


class SupportOfferResponse(BaseModel):
    id: int
    plan_id: int
    offered_by: str
    support_type: Literal[
        "join",
        "remind",
        "transport",
        "alternative",
        "booking",
        "encourage",
    ]
    note: str | None = None
    status: Literal["offered", "withdrawn"]
    created_at: datetime
    updated_at: datetime


class SupportOfferListResponse(BaseModel):
    support_offers: list[SupportOfferResponse]


class PlanNotificationResponse(BaseModel):
    id: int
    plan_id: int
    family_member_id: int
    recipient_name: str
    recipient_email: str | None = None
    status: Literal["pending", "sent", "failed"]
    provider_id: str | None = None
    error_message: str | None = None
    attempted_at: datetime | None = None
    sent_at: datetime | None = None
    created_at: datetime
    updated_at: datetime


class PlanNotificationListResponse(BaseModel):
    notifications: list[PlanNotificationResponse]


class NotificationDeliveryResponse(BaseModel):
    family_member_id: int
    name: str
    status: Literal["sent", "already_sent", "failed"]
    provider_id: str | None = None
    error: str | None = None


class NotificationDeliveryListResponse(BaseModel):
    deliveries: list[NotificationDeliveryResponse]
